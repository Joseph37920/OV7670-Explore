// define values for the registers for the various sizes of the capture images

// Register addresses and values

#define PID         0x0a                // product ID ms
#define VER         0x0b                // product ID ls
#define MIDH        0x0c                // Manufacturer ID byte High
#define MIDL        0x0d                // Manufacturer ID byte Low
#define CLKRC                 0x11      // internal clock default 0x80 
#define CLKRC_VALUE_VGA       0x01  // Raw Bayer divide by 1
#define CLKRC_VALUE_QQVGA     0x01

#define COM1                                   0x04
#define COM7                                   0x12
#define COLOR_CONTROL                          0X05
#define RAW_BAYER                              0X01    // Raw Bayer 
#define COM7_VALUE_VGA                         0x01   // Raw Bayer
#define COM7_VALUE_VGA_PROCESSED_BAYER         0x05   // Processed Bayer
#define CLEAR_RESOLUTION_BITS                  0X38   // [5:3] resolution bits - this is a mask to clear
#define COM7_VALUE_QVGA_COLOR_BAR              0x02
#define COM7_VALUE_QQVGA                       0x00
#define COM7_VALUE_QQVGA_COLOR_BAR             0x02   
#define COM7_VALUE_QCIF                        0x08     // Predefined QCIF format
#define COM7_VALUE_RESET                       0x80
#define COM7_RGB_SELECTION_BIT                 0X04
#define COM7_BAYER_SELECTION                   0X01

#define COM2                            0x09           

#define COM3                            0x0C 
#define COM3_VALUE_QVGA                 0x04
#define COM3_VALUE_QQVGA                0x04  // From Docs

#define COM14                           0x3E 
#define COM14_VALUE_QVGA                0x19
#define COM14_VALUE_QQVGA               0x1A

#define SCALING_XSC                                  0x70
#define SCALING_XSC_VALUE_QVGA                       0x3A
#define SCALING_XSC_VALUE_QQVGA                      0x3A

#define SCALING_YSC                                   0x71 
#define SCALING_YSC_VALUE_QVGA                        0x35
#define SCALING_YSC_VALUE_QQVGA                       0x35

#define SCALING_DCWCTR               0x72 
#define SCALING_DCWCTR_VALUE_QVGA    0x11
#define SCALING_DCWCTR_VALUE_QQVGA   0x22  

#define SCALING_PCLK_DIV              0x73  
#define SCALING_PCLK_DIV_VALUE_QVGA   0xF1             // these numbers look bogus - they work -- WHY?
#define SCALING_PCLK_DIV_VALUE_QQVGA  0xF2             // the "Bypass Clock Divider" bit is set ( its a 0 )


#define SCALING_PCLK_DELAY            0xA2
#define SCALING_PCLK_DELAY_VALUE_QVGA 0x02


// Controls YUV order Used with COM13
#define TSLB                                         0x3A
#define TSLB_UYVY_SELECTION_BIT                      0X08 


// Default value is 0x88
// ok if you want YUYV order, no need to change
#define COM13                      0x3D
#define COM13_VALUE_NOGAMMA_YUYV   0x00
#define COM13_VALUE_GAMMA_YUYV     0x80
#define COM13_VALUE_GAMMA_YVYU     0x82
#define COM13_YUV_SELECTION_BIT    0X01


// Works with COM4
#define COM17                                 0x42
#define COM17_VALUE_AEC_NORMAL_NO_COLOR_BAR   0x00
#define COM17_VALUE_AEC_NORMAL_COLOR_BAR      0x08 // Activate Color Bar for DSP
#define HISTOGRAM_BASED_AECAGC                0X80

#define COM4   0x0D

// RGB Settings and Data format
#define COM15    0x40
#define COM15_RGB5X5_5  0x20
#define COM15_RGB5X5_4 0X10



#define COM11                             0x3B

// Color Matrix Control YUV
#define MTX1	   	0x4f 
#define MTX2	   	0x50 
#define MTX3	   	0x51 
#define MTX4	   	0x52 
#define MTX5	   	0x53 
#define MTX6	   	0x54 
#define CONTRAS	   	0x56 
#define CONTRAS_VALUE	0x40

#define MTXS	   	0x58 
//#define MTXS_VALUE	0x9e



// COM8
#define COM8                    0x13
#define COM8_VALUE_AWB_BIT    0x02
#define COM8_BANDING_ON      0X20

// Vsync polarity
#define COM10                   0x15         // register name only


// Automatic White Balance
#define AWBC1	   	0x43 
#define AWBC1_VALUE	0x14

#define AWBC2	   	0x44 
#define AWBC2_VALUE	0xf0

#define AWBC3	   	0x45 
#define AWBC3_VALUE  	0x34

#define AWBC4	   	0x46 
#define AWBC4_VALUE	0x58

#define AWBC5	        0x47 
#define AWBC5_VALUE	0x28

#define AWBC6	   	0x48 
#define AWBC6_VALUE	0x3a

#define AWBC7           0x59
#define AWBC7_VALUE     0x88

#define AWBC8          0x5A
#define AWBC8_VALUE    0x88

#define AWBC9          0x5B
#define AWBC9_VALUE    0x44

#define AWBC10         0x5C
#define AWBC10_VALUE   0x67

#define AWBC11         0x5D
#define AWBC11_VALUE   0x49

#define AWBC12         0x5E
#define AWBC12_VALUE   0x0E

#define AWBCTR3        0x6C
#define AWBCTR3_VALUE  0x0A

#define AWBCTR2        0x6D
#define AWBCTR2_VALUE  0x55

#define AWBCTR1        0x6E
#define AWBCTR1_VALUE  0x11

#define AWBCTR0                0x6F
#define AWBCTR0_VALUE_NORMAL   0x9F

#define REG70 0x70       // Horizontal Scaling Ratio x1 to x1/2
#define REG71 0x71       // Vertical Scling Ratio x1 t0 x1/2


// Gain
#define COM9                        0x14

#define BLUE          0x01    // AWB Blue Channel Gain
#define BLUE_VALUE    0x40

#define RED            0x02    // AWB Red Channel Gain
#define RED_VALUE      0x40

#define GGAIN            0x6A   // AWB Green Channel Gain
#define GGAIN_VALUE      0x40

#define COM16	   	0x41 
//#define COM16_VALUE	0x08 // AWB Gain on

#define GFIX	   	0x69 

#define EDGE	   	0x3f 

#define REG74       0x74

#define REG75	   	0x75 

#define REG76	   	0x76 

// DeNoise 
#define DNSTH	   	0x4c 
//#define DNSTH_VALUE	0x00

#define REG77	   	0x77 
#define REG77_VALUE	0x00

// Denoise and Edge Enhancement -- fix these values and the routine that uses them
#define COM16_VALUE_DENOISE_ON__EDGE_ENHANCEMENT_OFF__AWBGAIN_ON    0x18
#define COM16_VALUE_DENOISE_OFF__EDGE_ENHANCEMENT_ON__AWBGAIN_ON    0x28
#define COM16_VALUE_DENOISE_ON__EDGE_ENHANCEMENT_ON__AWBGAIN_ON     0x38 // Denoise on,  Edge Enhancement on, AWB Gain on
#define COM16_VALUE_AWB_GAIN_BIT 0X08


// 30FPS Frame Rate , PCLK = 24Mhz
#define CLKRC_VALUE_30FPS  0x80

#define DBLV               0x6b    // PLL control and "internal regulator" default = a
#define EXHCH              0x2A    // dummy pixel insert MS  Defaults == 0
#define EXHCL              0x2B    // dummy pixel insert LS
#define DM_LNL               0x92  // dummy line low 8 bits
#define DM_LNH               0x93  // dummy line high lower 8 bits
#define COM11_VALUE_30FPS    0x0A   


// Saturation Control
#define SATCTR	   	0xc9 
#define SATCTR_VALUE	0x60 // default is bits 7-4 UV saturation control min, 0xc0 is the default


// AEC/AGC - Automatic Exposure/Gain Control
#define GAIN		0x00 
#define GAIN_VALUE	0x00

#define AEW	   	0x24 
#define AEW_VALUE	0x95

#define AEB	   	0x25 
#define AEB_VALUE	0x33

#define VPT	   	0x26 
#define VPT_VALUE	0xe3



// AEC/AGC Control- Histogram
#define HAECC1	   	0x9f 
#define HAECC2	   	0xa0 
#define HAECC3	   	0xa6 
#define HAECC4	   	0xa7 
#define HAECC5	   	0xa8 
#define HAECC6	   	0xa9 
#define HAECC7	                        0xaa  // AEC Algorithm selection
#define NALG                            0xaa // another name for HAECC7
#define HAECC7_VALUE_HISTOGRAM_AEC_ON	0x94 



/*
// Gamma
#define SLOP	   	0x7a 
#define SLOP_VALUE	0x20

#define GAM1	   	0x7b 
#define GAM1_VALUE	0x10

#define GAM2	   	0x7c 
#define GAM2_VALUE      0x1e

#define GAM3	   	0x7d 
#define GAM3_VALUE	0x35

#define GAM4	   	0x7e 
#define GAM4_VALUE	0x5a

#define GAM5	   	0x7f 
#define GAM5_VALUE	0x69

#define GAM6	   	0x80 
#define GAM6_VALUE	0x76

#define GAM7	   	0x81 
#define GAM7_VALUE	0x80

#define GAM8	   	0x82 
#define GAM8_VALUE	0x88

#define GAM9	   	0x83 
#define GAM9_VALUE	0x8f

#define GAM10	   	0x84 
#define GAM10_VALUE	0x96

#define GAM11	   	0x85 
#define GAM11_VALUE	0xa3

#define GAM12	   	0x86 
#define GAM12_VALUE	0xaf

#define GAM13	   	0x87 
#define GAM13_VALUE	0xc4

#define GAM14	   	0x88 
#define GAM14_VALUE	0xd7

#define GAM15	   	0x89 
#define GAM15_VALUE	0xe8

*/

// Array Control
#define CHLF	   	0x33 
#define CHLF_VALUE	0x0b

#define ARBLM	   	0x34 
#define ARBLM_VALUE	0x11



// ADC Control
#define ADCCTR1	   	0x21   // this register is reserved 
#define ADCCTR1_VALUE	0x02

#define ADCCTR2	   	0x22   // this register is reserved
#define ADCCTR2_VALUE	0x91

#define ADC	   	0x37        // this register is reserved   
#define ADC_VALUE       0x1d

#define ACOM	   	0x38        // this register is reserved
#define ACOM_VALUE	0x71

#define OFON	   	0x39        // this register is reserved
#define OFON_VALUE	0x2a


// Black Level Calibration
#define ABLC1	   	0xb1      // bit 2 (0x04) is the on/off bit rest is reserved
#define ABLC1_VALUE_ON   0x04

#define THL_ST		0xb3      // ABLC Target default = 80,  
#define THL_ST_VALUE	0x82


// Window Output 
#define HSTART               0x17
#define HSTART_VALUE_QVGA    0x13   
#define HSTART_VALUE_QQVGA   0x13

#define HSTOP                0x18
#define HSTOP_VALUE_QVGA     0x01  
#define HSTOP_VALUE_QQVGA    0x01

#define HREF                  0x32
//#define HREF_VALUE_DEFAULT    0x80
//#define HREF_VALUE_VGA        0xB6   
#define HREF_VALUE_QVGA       0x24  
#define HREF_VALUE_QQVGA      0xA4  

#define VSTRT                0x19
#define VSTRT_VALUE_QVGA     0x02
#define VSTRT_VALUE_QQVGA    0x02  
 
#define VSTOP                0x1A
#define VSTOP_VALUE_QVGA     0x7A
#define VSTOP_VALUE_QQVGA    0x7A  

#define VREF                 0x03
#define VREF_VALUE_QVGA      0x0A
#define VREF_VALUE_QQVGA     0x0A 




 
// AEC/AGC Control- Histogram
#define HAECC1     0x9f 
#define HAECC2      0xa0 
#define HAECC3      0xa6 
#define HAECC4      0xa7 
#define HAECC5      0xa8 
#define HAECC6      0xa9
#define HAECC7                          0xaa  // AEC Algorithm selection
#define NALG                            0xaa  // aka HAECC7

#define AECHH   0x07               // Exposure Value AEC MS 5 bits [AEC 15:10]
#define AECH    0x10               // Exposure Value [9:2] 

#define BAVE  0x05                 // U/B Average level (updated)
#define GbAVE 0x06                 // Y/Gb average level (updated)
#define RAVE  0x08                 // V/R Average level (updated)
#define YAVE  0x2F                 // YG Average level (updated)

#define B_LMT  0x5F                // White balance limits
#define R_LMT  0x60
#define G_LMT  0x61

#define RGB444 0x8c                // rgb format 555 565 etc control
#define RGB444_ENABLE  0X02
#define RGB444_RGBX      0X01



#define MVFP   0x1E                // flip horizontal & vertical
#define BRIGHT 0x55                // brightness
#define CONTRAS 0x56               // contrast
#define RBIAS   0x2c               // red bias
#define REG4B   0x4b               // average the UV values
#define DM_LUL  0x92               // dummy line counter low
#define DM_LUH  0X93               // dummy line counter high
#define MANU  0X67                 // manual U value
#define MANV   0X68                // manual V value

// define some bits
#define BIT0  0X01
#define BIT1  0X02
#define BIT2  0X04
#define BIT3  0X08
#define BIT4  0X10
#define BIT5  0X20
#define BIT6  0X40
#define BIT7  0X80

// define some flags
#define aec_on 1                   // automatic exposure control
#define aec_histogram 2            // select histogram AEC
#define aec_fast 4
#define matrix_double 8
#define matrix_on 16
#define light_mode_on 32
#define script_file_active 64
#define log_file_active 128
#define edge_on 256
#define denoise_on 512
#define ablcon_on 1024
#define aawb_on 2048
#define no_output 4096
#define histo_color 8192
#define color_bar 16384
#define float_YUV 32768       // 1 << 15
#define histo_lum 65536
#define histo_U     131072
#define histo_V 262144
#define FPS30   524288
#define freeze_AGC 1048576

// define macros to handle flags
#define setflag(var) setup_flags = setup_flags | var;
#define clearflag(var) setup_flags = setup_flags & ~var;
#define testflag(var) setup_flags & var 

