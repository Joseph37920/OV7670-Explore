//
/*
 * 4/24/16 - mods to this code - added "setReg" and "clearReg" to read register and the set or clear passed bits
 */

#include "Arduino.h"
#include "reg_defines.h"
#include "camera_routines.h"
#include "saturation.h"
#include "gamma.h"
#include <Wire.h>
#include "I2C_defs.h"

//#define byte char


// external values in main
extern int PHOTO_WIDTH;
extern int PHOTO_HEIGHT;
extern int PHOTO_BYTES_PER_PIXEL;
extern String YUVMatrixParam;
extern String DenoiseParam;
extern byte   edge_value;
//extern String ABLCParam;
extern bool detail;
extern byte edge_value;
extern byte h_scale;
extern byte v_scale;
extern byte bar_type;
extern byte image_flip;
extern byte image_mirror;
extern byte uv_average;
extern byte brightness;     // BRIGHT 0x42 - sets the image brightness
extern int8_t saturation;   // a number -2 to 2 that defines a list in saturation.h  
extern byte contrast;       // CONTRAST 0x56 - sets image contrast  
extern byte output_format;
extern long wait_for_sync();
extern byte de_noise_threshold;       // two registers that control
extern byte de_noise_reg77;           // the denoise function
extern byte band_value;
extern byte AGC_enable;
extern int gain_setting;
extern byte gain_ceiling;
extern long setup_flags;
extern int stable_upper_AEC;
extern int stable_lower_AEC;
extern int limit_upper_AEC;
extern int limit_lower_AEC;
extern byte AEC_window;
extern byte HAE1;
extern byte HAE2;
extern byte HAE3;
extern byte HAE4;
extern byte HAE5;
extern byte HAE6;
extern byte AEC_nib;
extern byte AEB_nib;
extern byte c_mode;
extern byte c_mode_ctl;
extern byte light_mode_red;
extern byte light_mode_blue;
extern byte r_tslb;
extern byte r_manu;
extern byte r_manv;
extern byte gamma_curve;

// prototypes
void setupQVGAWindow();
void setupQVGAScaling();
void DisplayError(String msg, int result);
// add code to modify registers

 // talk to camera via I2C
void startWire(){
      // Setup the OV7670 Camera for use in taking still photos
     Wire.begin();
}

 byte ReadRegisterValue(int RegisterAddress)
{
  byte data = 0;
  int result;
  
  Wire.beginTransmission(OV7670_I2C_ADDRESS);         
  result = Wire.write(RegisterAddress);                        
  if(result != 1){Serial.println("Result of write to camera register is: "); Serial.print((int)result,HEX); Serial.println();}
  Wire.endTransmission();
  Wire.requestFrom(OV7670_I2C_ADDRESS, 1);            
  while(Wire.available() < 1); // delay for data              
  data = Wire.read(); 

  return data;  
}

// --------------------------------------------------------------------------------------------------------------------
// Parameters:
//   start : Start address, use a define for the register
//   pData : A pointer to the data to write.
//   size  : The number of bytes to write.
//
int OV7670Write(int start, const byte *pData, int size)
{
  int n, error;

  Wire.beginTransmission(OV7670_I2C_ADDRESS);
  n = Wire.write(start);        // write the start address
  if (n != 1)
  {
    return (I2C_ERROR_WRITING_START_ADDRESS);
  }
  
  n = Wire.write(pData, size);  // write data bytes
  if (n != size)
  {
    return (I2C_ERROR_WRITING_DATA);
  }
  
  error = Wire.endTransmission(true); // release the I2C-bus
  if (error != 0)
  {
    return (error);
  }
  
  return 0;         // return : no error
}

//-----------------------------------------------------------------------------------------------------------
//
// A function to read a single register
//
int OV7670ReadReg(int reg)
{
  int error;

  error = ReadRegisterValue(reg);

  return (error);
}

// -------------------------------------------------------------------------------------------------------------------------
//
// A function to write a single register
//
int OV7670WriteReg(int reg, byte data)
{
  int error;
  String reg_n;
  error = OV7670Write(reg, &data, 1);
       if(error)
     {
          // find the register text value
          reg_n =  getRegName(reg);
          reg_n += ": ";
          DisplayError(reg_n,error);
     }

  return (error);
}
// -------------------------------------------------------------------------------------------------------------------------
String ParseI2CResult(int result)
{
  String sresult = "";
  switch(result)
  {
    case 0:
     sresult = "I2C Operation OK --";
    break;
    
    case  I2C_ERROR_WRITING_START_ADDRESS:
     sresult = "I2C_ERROR_WRITING_START_ADDRESS";
    break;
    
    case I2C_ERROR_WRITING_DATA:
     sresult = "I2C_ERROR_WRITING_DATA";
    break;
      
    case DATA_TOO_LONG:
     sresult = "DATA_TOO_LONG";
    break;   
    
    case NACK_ON_TRANSMIT_OF_ADDRESS:
     sresult = "NACK_ON_TRANSMIT_OF_ADDRESS";
    break;
    
    case NACK_ON_TRANSMIT_OF_DATA:
     sresult = "NACK_ON_TRANSMIT_OF_DATA";
    break;
    
    case OTHER_ERROR:
     sresult = "OTHER_ERROR";
    break;
       
    default:
     sresult = "I2C ERROR TYPE NOT FOUND...";
    break;
  }
 
  return sresult;
}
// ---------------------------------------------------------------------------------------------------------------
int setReg(int reg,byte val){      // set bit(s) in register without changing other bit values
     int result;
     byte temp;
     String reg_n;
     temp = ReadRegisterValue(reg);
     temp |= val;
     result = OV7670WriteReg(reg,temp);
     if(result)
     {
          // find the register text value
          reg_n =  getRegName(reg);
          reg_n += ": ";
          DisplayError(reg_n,result);
     }
     return result;
}

int clearReg(int reg,byte val){    // clear bit(s) in register without changing other bit values
     int result;
     byte temp;
     String reg_n;
     temp = ReadRegisterValue(reg);
     temp = temp & ~val;
     result = OV7670WriteReg(reg,temp);
          if(result)
     {
          // find the register text value
          reg_n =  getRegName(reg);
          reg_n += ": ";
          DisplayError(reg_n,result);
     }
     return result;
}

// read the exposure value passed by the camera
int readExposure(){
     byte temp;
     int exposure;
     // exposure is a 16 bit value - bits 15:10 are in AECHH [5:0], bits 9:2 are in AECH [7:0] and bits 1:0 are in COM1[1:0]
     temp = ReadRegisterValue(AECHH);
     exposure = temp << 9;
     temp = ReadRegisterValue(AECH);
     exposure |= temp << 2;
     temp = ReadRegisterValue(COM1);
     exposure |= temp & 0x03;
     return exposure;
}
// Edge() print the Edge information - On/Off and value of the enhancement and REG75 & REG76
void showEdge(){
     byte data,on_off;
     on_off = OV7670ReadReg(COM16);
     int val = OV7670ReadReg(EDGE);   
     val &=0x1F;  // trim to 5 bits
     int low = OV7670ReadReg(REG75);
     int hi  = OV7670ReadReg(REG76); 
     if(on_off & BIT5)
        Serial.print(F("\n\nEdge is ON, enhancement value is "));
     else
        Serial.print(F("\n\nEdge is OFF, enhancement value is "));   
     Serial.print(val);Serial.println(F(" decimal."));
     Serial.print(F("REG75 Lower value is "));Serial.println(low);
     Serial.print(F("REG76 Upper value is "));Serial.println(hi);Serial.println(F("\n\n"));
}
// showDeNoise() prints the current state of the denoise routines
void showDeNoise(){
     if(OV7670ReadReg(COM16) & BIT4)
        Serial.println(F("\n\nAutomatic DeNoise function is turned On"));
        else
        Serial.println(F("\n\nAutomatic DeNoise function is turned Off"));
     Serial.print(F("0x4c DNSTH register = "));Serial.println(OV7670ReadReg(DNSTH),HEX);   
     Serial.print(F("0x77 REG77 register = "));Serial.println(OV7670ReadReg(REG77),HEX);
     Serial.println("\n");
}

// print the Average values of the YUV
void printYUV(){
     Serial.print(F("Y/Gb average = "));Serial.print(ReadRegisterValue(GbAVE),HEX);
     Serial.print(F(" U/B average = "));Serial.print(ReadRegisterValue(BAVE),HEX);
     Serial.print(F(" V/R average = "));Serial.print(ReadRegisterValue(RAVE),HEX);
     Serial.print(F(" Y/G average = "));Serial.println(ReadRegisterValue(YAVE),HEX);     
}    // end print YUV

void printDeNoise(){
     byte data;
     data = ReadRegisterValue(DNSTH);
     Serial.print(F("0x4c DNSTH DeNoise strength = "));Serial.println(data,HEX); 
}
void printGainValue(byte val){
     switch(val){
          case 0:
          Serial.print(F(" 1x "));
          break;
          case 1:
          Serial.print(F(" 1.25x "));
          break;
          case 2:
          Serial.print(F(" 1.5x "));
          break;
          case 3:
          Serial.print(F(" 1.75x "));
          break;
          default:
          return;
     }
}
void printFixedGain(){
     byte gain;
     byte register_value;
     gain = ReadRegisterValue(GFIX);
     register_value = (gain & 0xc0)>>6;
     Serial.print(F("Gr Channel = "));
     printGainValue(register_value);
     register_value = (gain & 0x30)>>4;
     Serial.print(F("Gb Channel = "));
     printGainValue(register_value);
     register_value = (gain & 0x0c)>>2;
     Serial.print(F("R Channel = "));
     printGainValue(register_value);     
     register_value = (gain & 0x03);
     Serial.print(F("B Channel = "));
     printGainValue(register_value);
     gain = ReadRegisterValue(GGAIN);
     Serial.print(F(" G Channel ABW Gain "));Serial.println(gain,HEX);          
}
// assemble the bits from 6 registers into two 11 bit numbers - horizontal and two 10 bit numbers - vertical
// perhaps the DCW bits should be translated also
void printWindowParameters(){
#define HREF_edge 0xC0   // two bits of unknown use "edge offset to data output"
#define HSTOP_LS3 0x38   // HREF has LS three bits of the HSTOP ( 11 bits total)
#define HSTART_LS3 0x07  // HREF has LS three bits of the HSTART as above
#define VSTART_LS2 0x03
#define VSTOP_LS2 0x0C
int hstart = 0;
int hstop = 0;
int vstart = 0;
int vstop = 0;
byte COM3_2=0;
byte COM7_5_3 = 0;
byte COM14_4= 0;
int hsize,vsize;
     hstart = ReadRegisterValue(HSTART) <<3;
     hstart |= (ReadRegisterValue(HREF)& HSTART_LS3);
     hstop = ReadRegisterValue(HSTOP) <<3;
     hstop |= (ReadRegisterValue(HREF)& HSTOP_LS3) >>3;
     vstart = ReadRegisterValue(VSTRT) <<2;
     vstart |= ReadRegisterValue(VREF) & VSTART_LS2;
     vstop = ReadRegisterValue(VSTOP) << 2;
     vstop |= (ReadRegisterValue(VREF) & VSTOP_LS2) >>2;
//      
     vsize = vstop - vstart;  // number of rows
     hsize = hstop - hstart;  // number of columns   
     Serial.println(F("\n  Window Parameters"));
     Serial.print(F("H Start = "));Serial.print(hstart);Serial.print(F(" H Stop = "));Serial.println(hstop);
     Serial.print(F("V Start = "));Serial.print(vstart);Serial.print(F(" V Stop = "));Serial.println(vstop);
     Serial.print(F("Picture Width = "));Serial.print(hsize);Serial.print(F("  Picture Height = "));Serial.print(vsize);
     Serial.println();
// now show the DCW bits
     COM3_2 = (ReadRegisterValue(COM3) & 0x04) >> 2;
     COM7_5_3 = (ReadRegisterValue(COM7) & 0x31) >> 3;
     COM14_4 = (ReadRegisterValue(COM14) & 0x10) >> 4;
     if(COM3_2){    // DCW bit set enabled
          if(COM7_5_3){  // predefined format selected
               if(COM14_4){
                   Serial.println(F("DCW bit enable \(COM3[2]\) and COM14[4] bit enabled with Predefined Formats selected."));
                   Serial.print(F("SCALING_PCLK_DIV[3:0] = "));Serial.print((ReadRegisterValue(SCALING_PCLK_DIV) & 0x0f));
                   Serial.print(F("COM14 PCLK[3:0] = "));Serial.print((ReadRegisterValue(COM14) & 0x07));
               }
               else
               {
                    Serial.println(F("DCW bit enable \(COM14[4]\) and no predefined format selected ."));     
               }
               
                    
          }
          else
          {
               Serial.println(F("DCW bit enabled \(COM3[2]\) and no Predefined Formats selected."));
               if(COM14_4)Serial.print(F("DCW bit enabled \(COM14[4]\)."));
               else Serial.print(F("DCW bit not enabled \(COM14[4]\)."));
               Serial.println();
               Serial.print(F("SCALING_PCLK_DIV[3:0] count is = "));Serial.println((ReadRegisterValue(SCALING_PCLK_DIV) & 0x0f));
               Serial.print(F("COM14 PCLK[3:0] count = "));Serial.println((ReadRegisterValue(COM14) & 0x07));
          }
     }
     else Serial.println(F("No DCW setting active"));
     Serial.println("\n");

     
}    // end of printWindowParameters

// Show Flags - printout the flags that are active or the if/else values for the flags
void showflags(){
     if(testflag(aec_on))Serial.println(F("Automatic Exposure Control is ON")); else Serial.println(F("Automatic Exposure Control is OFF"));
     if(testflag(aec_histogram))Serial.println(F("AEC is using Histogram Control")); else Serial.println(F("AEC is using Averaging Control"));
     if(testflag(aec_fast))Serial.println(F("Automatic Exposure Control is FAST")); else Serial.println(F("Automatic Exposure Control is SLOW"));
     if(testflag(matrix_double))Serial.println(F("YUV Matrix Double is ON")); else Serial.println(F("YUV Matrix is normal"));
     if(testflag(matrix_on)){Serial.print(F("Color Saturation Matrix in use Number "));Serial.println(saturation);}
     if(testflag(light_mode_on)){Serial.print(F("Light Mode is set to ON. RED =  "));Serial.print(light_mode_red); Serial.print(F(" BLUE = "));
        Serial.print(light_mode_red);}
     if(testflag(ablcon_on))Serial.println(F("Automatic Black Level Control is ON."));
     if(testflag(script_file_active))Serial.println(F("A Script File is Running!"));
     if(testflag(log_file_active))Serial.println(F("A Log File is being written!"));
     if(testflag(edge_on)){Serial.print(F("The Edge Enhancement is active; Value is "));Serial.println(edge_value);}
     if(testflag(denoise_on))Serial.println(F("The Denoise Mode is ON."));
     if(testflag(aawb_on))Serial.println(F("Simple Automatic White Balance is ON."));
     if(testflag(no_output))Serial.println(F("No Photo Data is being written to the SD card."));
     if(testflag(histo_color))Serial.println(F("A Color Histogram is being written."));
     if(testflag(color_bar))Serial.println(F("The COLOR BAR is being displayed."));
     if(testflag(float_YUV))Serial.println(F("The floating point YUV conversion is being used"));
               else Serial.println(F("The fixed point YUV conversion if being used"));
     if(testflag(histo_lum))Serial.println(F("A Luminance histogram is being written."));
     if(testflag(histo_U))Serial.println(F("A U value histogram is being written."));
     if(testflag(histo_V))Serial.println(F("A V value histogam is being written."));
}    // end of showflags()

// Scaling prameters are from four registers - see manual & application notes for more info
void printScalingFactors(){
byte dcwctr;
byte pclk_div;
int div_val,reg74,reg75;
float x_scale,y_scale;

     Serial.println(F("\nScaling Factors"));
//     Serial.print(F("SCALING_XSC register = "));Serial.print((ReadRegisterValue(SCALING_XSC)&0x3f),HEX);
//     Serial.print(F("\nSCALING_YSC register = "));Serial.print((ReadRegisterValue(SCALING_YSC)&0x3f),HEX);Serial.println();
     div_val = ReadRegisterValue(COM3) & 0x08;
     if(div_val)Serial.println(F("\nCOM3[3] is set to a one, \"Scaling is enabled\""));
     else
          Serial.println(F("\nCOM3[3] not set. \"Scaling is NOT enabled\""));     
     div_val = ReadRegisterValue(COM3) & 0x10;
     if(div_val)Serial.println(F("\nCOM3[4] is set to a one, \"Down Sampling enabled\""));
     else
          Serial.println(F("\nCOM3[4] is not set to a one, \"Down Sampling NOT enabled\""));          
     div_val = ReadRegisterValue(COM14) & 0x08;
     if(div_val)Serial.println(F("\nCOM14[3] is set to a one, \"Manual scaling for predefined resolution\"\n"));
     else
          Serial.println(F("\nCOM14[3] is zero, \"Manual scaling NOT enabled for predefined resolution\"\n"));
          
     Serial.println(F("The allowed values for the next two registers ranges from 0x20 to 0x40 - x1 to x1/2"));     
     Serial.print(F("REG70 - \"Horizontal Scaling Ratio\" = "));Serial.println((ReadRegisterValue(REG70) & 0x7f),HEX);
     Serial.print(F("REG71 - \"Vertical Scaling Ratio\" = "));Serial.println((ReadRegisterValue(REG71) & 0x7f),HEX);
     Serial.print(F("\nSCALING_PCLK_DELAY - \"Horizontal Size factor\" = "));Serial.println((ReadRegisterValue(SCALING_PCLK_DELAY)& 0X0F),HEX);          
     Serial.println("");
     if((ReadRegisterValue(SCALING_PCLK_DIV)& 0X08)){
          Serial.print(F("PCLK_DIV is enabled."));
          Serial.print(F(" PCLK_DIV value is "));
          pclk_div = (ReadRegisterValue(SCALING_PCLK_DIV) & 0x07);
          switch(pclk_div){
               case 0:
               div_val = 1;
               break;
               case 1:
               div_val = 2;
               break;
               case 2:
               div_val = 4;
               break;
               case 3:
               div_val = 8;
               break;
               case 4:
               div_val = 16;
               break;
               default:
               div_val = 0; // illegal value
               break;
          }
          
          if(div_val == 0)Serial.println(F("set to an illegal value "));
          else Serial.println(div_val);
          }// end pclk_div is set
          // now the messy one
          dcwctr = ReadRegisterValue(SCALING_DCWCTR);
          Serial.print(F("Vertical average calculation = "));
          if(dcwctr & 0x80)Serial.print(F("Vertical Rounding\n"));
          else
          Serial.print(F("Vertical Truncation\n"));
          
          Serial.print(F("Vertical down sampling option = "));
          if(dcwctr & 0x40)Serial.print(F("Vertical rounding\n"));
          else
          Serial.print(F("Vertical Truncation\n"));          

          Serial.print(F("Vertical down sampling rate = "));
          div_val = (dcwctr & 0x30) >> 4;
          if(div_val == 0)Serial.print(F("No Vertical downsampling\n"));
          if(div_val == 1)Serial.print(F("Vertical downsample by two\n"));
          if(div_val == 2)Serial.print(F("Vertical downsample by four\n"));          
          if(div_val == 3)Serial.print(F("Vertical downsample by eight\n"));
          Serial.print(F("Horizontal Average CAlculation option = "));
          if(dcwctr & 0x08)Serial.print(F("Horizontal Rounding\n"));
          else Serial.print(F("Horizontal Truncation\n"));
          Serial.print(F("Horizontal Down Sampling Rate = "));
          if((dcwctr & 0x3) == 0)Serial.print(F("Horizontal down sampling\n"));
          if((dcwctr & 0x3) == 1)Serial.print(F("Horizontal down sample by two\n"));
          if((dcwctr & 0x3) == 2)Serial.print(F("Horizontal down sample by four\n"));
          if((dcwctr & 0x3) == 3)Serial.print(F("Horizontal down sample by eight\n"));

          Serial.println();                                        
          
}
// Show the current output type 
void showOutputType(){
     Serial.print(F("\nThe Output Format is "));
     // test COM7[2]
     // in reference to COM13 all BIT0 changed to BIT1
     if(!(OV7670ReadReg(COM7) & BIT2)){ //COM7[2] not set, format must be one of: YUYV,YVYU,UYVY,VYUY or Bayer Raw
          if(OV7670ReadReg(COM7) & BIT0) Serial.println(F("Bayer Raw"));
          else
          {                             // COM7[0] & COM7[2] both are zero then YUYV,YVYU,UYVY or VYUY
               if((OV7670ReadReg(TSLB) & BIT3) && (OV7670ReadReg(COM13) & BIT0)) // TSLB[3] and COM13[0] 
                    Serial.println(F("VYUY"));
               else
               if((OV7670ReadReg(TSLB) & BIT3) && (~(OV7670ReadReg(COM13) & BIT0)))     // TSLB[3] = 1 & COM13[0] = 0
                    Serial.println(F("UYVY"));
               else
               if(~(OV7670ReadReg(TSLB) & BIT3) && (OV7670ReadReg(COM13) & BIT0))     // TSLB[3] = 0 & COM13[0] = 1     
                    Serial.println(F("YVYU"));
               else
                    Serial.println(F("YUYV"));     
          }
     }
     else
     {                                  //COM7[2] set, format must be one of: RGB565,RGB555.RGBx444,RGB444x or Processed Bayer Raw
          if((OV7670ReadReg(COM7) & BIT0))   // COM7[2]=1 and COM7[0] = 1 is 
               Serial.println(F("Processed Bayer Raw"));
          else
          if((OV7670ReadReg(COM15) & BIT4))  // COM7[0]=0 and COM15[4]=1 must be RGB565 or RGB555
          {
               if((OV7670ReadReg(COM15) & BIT5)) Serial.println(F("RGB555"));
               else
               Serial.println(F("RGB565")); 
          }
          else
          if((OV7670ReadReg(RGB444) & BIT1)&&(OV7670ReadReg(RGB444) & BIT0))     // RGB444 bits 1 & 0 both set
               Serial.println(F("RGB444x"));
          else
          if((OV7670ReadReg(RGB444) & BIT1)) Serial.println(F("RGBx444"));     
     }
     Serial.println();
} // end showOutputType()

// Setup the output type for the data collected by the camera
void setupOutputType(){
     // selection is in output_format - it is an enumeration
     // remove any current configuration
     clearReg(COM7,COM7_RGB_SELECTION_BIT);
     clearReg(COM7,COM7_BAYER_SELECTION);
     clearReg(COM13,COM13_YUV_SELECTION_BIT);
     clearReg(TSLB,TSLB_UYVY_SELECTION_BIT);
     clearReg(COM15,COM15_RGB5X5_5 | COM15_RGB5X5_4);
     PHOTO_BYTES_PER_PIXEL = 2;         // default for all YUV data
     switch(output_format){
          case YUYV:     // default for all zeros                                         
          break;
          case YVYU:
               setReg(COM13,COM13_YUV_SELECTION_BIT);
          break;
          case UYVY:
               setReg(TSLB,TSLB_UYVY_SELECTION_BIT);
          break;
          case VYUY:
               setReg(TSLB,TSLB_UYVY_SELECTION_BIT);
               setReg(COM13,COM13_YUV_SELECTION_BIT);
          break;
          case RGB565:
               setReg(COM7,COM7_RGB_SELECTION_BIT);
               setReg(COM15,COM15_RGB5X5_4);
               c_mode = c_mode_ctl = 'D';
          break;
          case RGB555:
               setReg(COM7,COM7_RGB_SELECTION_BIT);
               setReg(COM15,COM15_RGB5X5_4);
               setReg(COM15,COM15_RGB5X5_5);
          break;
          case RGBx444:
               setReg(COM7,COM7_RGB_SELECTION_BIT);
               setReg(RGB444,RGB444_ENABLE);
          break;
          case RGB444x:
               setReg(COM7,COM7_RGB_SELECTION_BIT);
               setReg(RGB444,RGB444_ENABLE);
               setReg(RGB444,RGB444_RGBX);
          break;
          case BAYERRAW:
               setReg(COM7,COM7_BAYER_SELECTION);
               c_mode = c_mode_ctl = 0;
               PHOTO_BYTES_PER_PIXEL = 1;
          break;
          case PROCESSEDBAYER:
               setReg(COM7,COM7_BAYER_SELECTION);
               setReg(COM7,COM7_RGB_SELECTION_BIT);
               PHOTO_BYTES_PER_PIXEL = 1;
          break;
          default:
               Serial.println(F("Invalid Output_Mode selection - UYVY set as default."));
               setReg(TSLB,TSLB_UYVY_SELECTION_BIT);
               output_format = UYVY;
          break;
          
     }; // end switch

}    // end of setup output type

// setup saturation
void setupSaturation(){
     // load the YUV conversion registers
int index = 0;
uint8_t reg_lst[7];    // get rom storage values to local
uint8_t val_list[7];
     for(index=0; index<7;index++)reg_lst[index] = pgm_read_byte_far(register_list + index);   // register values are common
     switch(saturation){
     case 2:
     for(index=0; index<7;index++)val_list[index] = pgm_read_byte_far(saturation2 + index);     
     break;                    
     case 1:
     for(index=0; index<7;index++)val_list[index] = pgm_read_byte_far(saturation1 + index);     
     break;
     case 0:
     for(index=0; index<7;index++)val_list[index] = pgm_read_byte_far(saturation0 + index);     
     break;
     case -1:
     for(index=0; index<7;index++)val_list[index] = pgm_read_byte_far(saturationm1 + index);          
     break;
     case -2:
     for(index=0; index<7;index++)val_list[index] = pgm_read_byte_far(saturationm2 + index);          
     break;
     default:
     Serial.println(F("Saturation Matrix Load Failure check saturation value."));
     Serial.print(F("Value of Saturation index is "));Serial.println(saturation);
     return;
     }
     // now loadup the registers
     for(index = 0; index<7;index++)OV7670WriteReg(reg_lst[index],val_list[index]);
     // check for matrix_double flag
     if((testflag(matrix_double))){
          setReg(COM16,BIT1);
     }
     else
     {
          clearReg(COM16,BIT1);
     }
}
// setup contrast
void setupContrast(){
     OV7670WriteReg(CONTRAS,contrast);
}
// show current banding
void showBanding(){
     int found = 0;
     // check autodetect
     if(OV7670ReadReg(COM11) & BIT4){Serial.println(F("\nBanding Auto Detect is set"));found = 1;}
     if(OV7670ReadReg(COM8) & BIT5){Serial.println(F("Banding Filter is turned on COM8[5]")); found = 1;}
     if(OV7670ReadReg(COM11) & BIT3){Serial.println(F("50 Hertz banding filter selected")); found = 1;}
     else
          if(OV7670ReadReg(COM8) & BIT5){Serial.println(F("60 Hertz banding filter selected")); found = 1;}
     if(!found)Serial.println(F("Banding filter is not turned on."));
}
// banding setup
void setupBanding(){
     if(band_value != BNULL){
          // clear all the selection bits ( turn off banding)
          clearReg(COM11,BIT4);
          clearReg(COM11,BIT3);
          clearReg(COM8,BIT5);
     }
     switch(band_value){
          case BNULL:         // no banding information available
          break;
          case B50:           // request 50 Hertz banding
               setReg(COM11,BIT3);
               setReg(COM8,BIT5);
          break;
          case B60:           // request 60
               setReg(COM8,BIT5);
          break;
          case BAUTO:         // request auto detect of banding frequency
               setReg(COM11,BIT4);
          break;
          case BOFF:          // turn off the banding
          break;
          default:
               Serial.println(F("Invalid Banding select constant - program ERROR!"));
          break;
     }
     
}
// showAGC - display the Automatic Gain Control settings
void showAGC(){
     if(OV7670ReadReg(COM8) & BIT2)Serial.println(F("\nAGC is Enabled"));
     else Serial.println(F("\nAGC is Disabled"));
     int gain_setting = ((OV7670ReadReg(VREF) & 0xC0) << 2);
     gain_setting |= OV7670ReadReg(GAIN);
     Serial.print(F("Gain Setting = "));Serial.println(gain_setting);
     int gain_ceiling = (OV7670ReadReg(COM9) & 0x70)>>4;
     Serial.print(F("Gain Limit is "));Serial.println((2 << gain_ceiling));
     if(OV7670ReadReg(COM9) & 0x01)Serial.println(F("AGC freeze bit is set"));
     else
     Serial.println(F("AGC freeze bit is NOT set")); 
     
}
void setupAGC(){
     // set AGC bit in COM8
     clearReg(COM8,BIT2);
     if(AGC_enable)setReg(COM8,BIT2);
     int gain_x = gain_setting & 0x300; // extract bits 9:8
     gain_x = gain_x >>2;     // make bits 7:6
     clearReg(VREF,BIT7 | BIT6);   // mask out current bits
     setReg(VREF,gain_x);          // set new bits
     gain_x = gain_setting & 0xff;
     OV7670WriteReg(GAIN,gain_x);
     clearReg(COM9,BIT6 | BIT5 | BIT4); // clear ceiling bits
     setReg(COM9,(gain_ceiling & 0x7) << 4);
     if(testflag(freeze_AGC))setReg(COM9,BIT0); else clearReg(COM9,BIT0);
}
void showAEC(){
int exposure;
float t_exposure;
     exposure = (OV7670ReadReg(AECHH) & 0x3F) << 10;
     exposure |= (OV7670ReadReg(AECH) << 2);
     exposure |= (OV7670ReadReg(COM1) & 0x03);
     t_exposure = (float)exposure * 6.5333E-5;
     if(OV7670ReadReg(COM8) & BIT0)Serial.println(F("\nAEC is Enabled"));
     else Serial.println(F("\nAEC is not Enabled"));
     if(OV7670ReadReg(COM8) & BIT7)Serial.println(F("AEC Fast Mode"));
     else Serial.println(F("AEC Slow Mode"));
     if(OV7670ReadReg(NALG) & BIT7)Serial.println(F("Histogram based AEC algorithm enabled"));
     else Serial.println(F("Average based AEC algorithm enabled"));
     // Luminance calculation window COM4[5:4] and COM17[7:6] must be the same
     int lum4 = (OV7670ReadReg(COM4) >> 4) & 3;
     int lum17 = (OV7670ReadReg(COM17) >> 6) & 3;
     if(lum4 != lum17){
          Serial.println(F("COM4 does not equal COM17 settings!"));
          Serial.print(F("COM4 = "));Serial.println(lum4);
          Serial.print(F("COM17 = "));Serial.println(lum17);
          Serial.println(F("Using COM4 values."));
     }
     Serial.print(F("Exposure time = "));Serial.print(t_exposure,4); Serial.println(F(" Seconds"));
     
     Serial.print(F("The Luminance is calculated over "));
     switch(lum4){
          case 0:
               Serial.println(F("the Full Window"));
          break;
          case 1:
               Serial.println(F("one half center Window"));
          break;
          case 2:
               Serial.println(F("one quarter center Window"));
          break;
          case 3:
               Serial.println(F("one quarter center Window"));
          break;
          default:
               Serial.print(F("Program error in showAEC Switch on lum4 value is "));Serial.println(lum4);
          break;
     }
     
     
     if(OV7670ReadReg(NALG) & BIT7) // display the histogram registers if AEC in histogram mode
     {
          // the sequence is that of the "Implementation Guide" as shown on Table 3-8
          Serial.print(F("HAECC2/LRL Low Reference Luminance = "));Serial.println(OV7670ReadReg(HAECC2));
          Serial.print(F("HAECC1/HRL High Reference Luminance = "));Serial.println(OV7670ReadReg(HAECC1));
          Serial.print(F("HAECC3/LPH Lower Limit for Probability for HRL = "));Serial.println(OV7670ReadReg(HAECC3));
          Serial.print(F("HAECC4/UPL Upper Limit for Probability for LRL = "));Serial.println(OV7670ReadReg(HAECC4));
          Serial.print(F("HAECC5/TPL Probability Threshold for LRL = "));Serial.println(OV7670ReadReg(HAECC5));
          Serial.print(F("HAECC6/TPH Probability Threshold for HRL = "));Serial.println(OV7670ReadReg(HAECC2));
          Serial.print(F("AEW/TLH High Nibble of Luminance High Threshold = "));Serial.println((OV7670ReadReg(AEW) >> 4) & 0x0F);
          Serial.print(F("AEB/TLL High Nibble of Luminance Low Threshold = "));Serial.println((OV7670ReadReg(AEB) >> 4) & 0x0F);
     }
     else
     {                               // display the average registers
          Serial.print(F("Stable Operating Region Upper Limit "));Serial.println(OV7670ReadReg(AEW));    
          Serial.print(F("Stable Operating Region Lower Limit "));Serial.println(OV7670ReadReg(AEB));
          Serial.print(F("Control Zone Upper Limit "));Serial.println((OV7670ReadReg(VPT) & 0xF0)>> 4);
          Serial.print(F("Control Zone Lower Limit "));Serial.println((OV7670ReadReg(VPT) & 0x0F));
     }
     Serial.println();   // seperate output
}
// setup AEC controls
void setupAEC(){
     // AEC 0n/off
     if(testflag(aec_on))setReg(COM8,BIT0);
     else clearReg(COM8,BIT0);
     // AEC average/histogram
     if(testflag(aec_histogram))setReg(NALG,BIT7);
     else clearReg(NALG,BIT7);
     // AEC fast/slow
     if(testflag(aec_fast))setReg(COM8,BIT7);
     else clearReg(COM8,BIT7);
     // AEC luminance window in AEC_window
     clearReg(COM4,BIT5 | BIT4);
     clearReg(COM17,BIT7 | BIT6);
     setReg(COM4,AEC_window << 4);
     setReg(COM17,AEC_window << 6);
     
     // Control Zone lower/upper limits AEC Average only
     OV7670WriteReg(VPT,(limit_upper_AEC << 4) | limit_lower_AEC); // two nibbles
     
     // stable operating region upper limit
     OV7670WriteReg(AEW,stable_upper_AEC);
     // stable operating reagion lower limit
     OV7670WriteReg(AEB,stable_lower_AEC);
     
     // setup histogram data here as needed
     OV7670WriteReg(HAECC1,HAE1);
     OV7670WriteReg(HAECC2,HAE2);
     OV7670WriteReg(HAECC3,HAE3);
     OV7670WriteReg(HAECC4,HAE4);
     OV7670WriteReg(HAECC5,HAE5);
     OV7670WriteReg(HAECC6,HAE6);
     if(OV7670ReadReg(NALG) & BIT7)
     {    // overrite AEW and AEB only if histogram active
     clearReg(AEW,0xf0);
     setReg(AEW,AEC_nib << 4);
     clearReg(AEB,0xf0);
     setReg(AEB,AEB_nib << 4);
     }
}
// support for GFIX output
void print_gfix(byte val){
     switch(val){
          case 0:
          Serial.println(F("1x"));
          break;
          case 1:
          Serial.println(F("1.25x"));
          break;
          case 2:
          Serial.println(F("1.5x"));
          break;
          case 3:
          Serial.println(F("1.75x"));
          break;
          default:
          Serial.println(F("GFIX value is not defined"));
     }
}
// show the Automatic White Balance Settings
void showAWB()
{
     byte sv_gfix=0;
     Serial.println(F("\n          Automatic White Balance Report\n"));
     if(OV7670ReadReg(COM8) & BIT1) Serial.println(F("White Balance in Automatic Mode"));
     else
     Serial.println(F("White Balance in Manual Mode"));
     if(OV7670ReadReg(AWBCTR0) & BIT0) Serial.println(F("Normal Automatic White Balance mode"));
     else
     Serial.println(F("Advanced Automatic White Balance mode"));
     if(OV7670ReadReg(AWBCTR0) & BIT3) Serial.println(F("Automatic White Balance adjusts R,G and B Gain"));
     else
     Serial.println(F("Advanced Automatic White Balance adjusts R and B Gain only"));
     if(OV7670ReadReg(AWBCTR0) & BIT2) Serial.println(F("Maximum Color Gain is 4x"));
     else
     Serial.println(F("Maximum Color Gain is 2x"));
     Serial.print(F("Blue Channel Gain = "));Serial.println(OV7670ReadReg(BLUE),DEC);
     Serial.print(F("Red Channel Gain = "));Serial.println(OV7670ReadReg(RED),DEC);
     Serial.print(F("Gr, Gb Channel Gain = "));Serial.println((OV7670ReadReg(GGAIN)&0X7f),DEC);
     Serial.print(F("ABW Blue Gain Range Upper Limit ="));Serial.println(((OV7670ReadReg(B_LMT)&0xF0)>>4),DEC);
     Serial.print(F("ABW Blue Gain Range Lower Limit ="));Serial.println((OV7670ReadReg(B_LMT)&0x0F),DEC);
     Serial.print(F("ABW Red Gain Range Upper Limit ="));Serial.println(((OV7670ReadReg(G_LMT)&0xF0)>>4),DEC);
     Serial.print(F("ABW Red Gain Range Lower Limit ="));Serial.println((OV7670ReadReg(G_LMT)&0x0F),DEC);
     Serial.print(F("ABW Green Gain Range Upper Limit ="));Serial.println(((OV7670ReadReg(G_LMT)&0xF0)>>4),DEC);
     Serial.print(F("ABW Green Gain Range Lower Limit ="));Serial.println((OV7670ReadReg(G_LMT)&0x0F),DEC);
     sv_gfix = OV7670ReadReg(GFIX);     // has four different values
     Serial.print(F("Gr channel pre-gain "));print_gfix((sv_gfix & 0xC0)>>6);
     Serial.print(F("Gb channel pre-gain "));print_gfix((sv_gfix & 0x30)>>4);
     Serial.print(F("Red channel pre-gain "));print_gfix((sv_gfix & 0x0C)>>2);
     Serial.print(F("Blue channel pre-gain "));print_gfix((sv_gfix & 0x03));
     Serial.println("\n");
}    // end showAWB
// show light mode
void showLightMode(){
     //ABW on off,red,blue gain
     if(OV7670ReadReg(COM8)&BIT1)Serial.println(F("Automatic White Balance is OFF"));
     else Serial.println(F("Automatic White Balance is ON"));
     Serial.print(F("RED Channel gain is "));Serial.println(OV7670ReadReg(RED));
     Serial.print(F("BLUE Channel gain is "));Serial.println(OV7670ReadReg(BLUE));
}
// setup light mode by using the values stored in light_mode_red and light_mode_blue and the control bit light mode on
void setupLightMode(){
     if(testflag(light_mode_on)){
          OV7670WriteReg(RED,light_mode_red);
          OV7670WriteReg(BLUE,light_mode_blue);
          clearReg(COM8,BIT2); // turn off the automatic white balance
     }
     else
     {
          setReg(COM8,BIT2); // turn on automatic white balance
     }
}
// YUV conversion matrix display
void show_YUV_matrix(){
byte signs=0;
int  val;
float f_val;
     Serial.println(F(" Current Values for the YUV in the internal camera Conversion Matrix"));
     signs = OV7670ReadReg(MTXS);
     val = OV7670ReadReg(MTX1);
     if(signs & BIT0)val = -val;
     f_val = (float)val/128;
     Serial.print(F("Matrix1 fixed = "));Serial.print(val);Serial.print(F(" Float = "));Serial.println(f_val);

     val = OV7670ReadReg(MTX2);
     if(signs & BIT1)val = -val;
     f_val = (float)val/128;
     Serial.print(F("Matrix1 fixed = "));Serial.print(val);Serial.print(F(" Float = "));Serial.println(f_val);

     val = OV7670ReadReg(MTX3);
     if(signs & BIT2)val = -val;
     f_val = (float)val/128;
     Serial.print(F("Matrix3 fixed = "));Serial.print(val);Serial.print(F(" Float = "));Serial.println(f_val);               

     val = OV7670ReadReg(MTX4);
     if(signs & BIT3)val = -val;
     f_val = (float)val/128;
     Serial.print(F("Matrix4 fixed = "));Serial.print(val);Serial.print(F(" Float = "));Serial.println(f_val);     

     val = OV7670ReadReg(MTX5);
     if(signs & BIT4)val = -val;
     f_val = (float)val/128;
     Serial.print(F("Matrix5 fixed = "));Serial.print(val);Serial.print(F(" Float = "));Serial.println(f_val);

     val = OV7670ReadReg(MTX6);
     if(signs & BIT5)val = -val;
     f_val = (float)val/128;
     Serial.print(F("Matrix6 fixed = "));Serial.print(val);Serial.print(F(" Float = "));Serial.println(f_val);     
}    // end show_YUV

// special effects modify the MANU and MANV registers to override the computed values
// the TSLB is setup for various bit patters having to do with negative etc.
void specialEffects(){
     byte temp;
     temp = OV7670ReadReg(TSLB);
     temp = temp & 0xCF; // mask out bits 5 & 4
     temp = temp | r_tslb;
     OV7670WriteReg(TSLB,temp);
     OV7670WriteReg(MANU,r_manu);
     OV7670WriteReg(MANV,r_manv);
}

// ======= DisplayError - show the error in using the I2C camera interface 
void DisplayError(String msg, int result){
String r_msg;     
     Serial.print(msg);Serial.print(" ");
     r_msg = ParseI2CResult(result);
     Serial.println(r_msg);
}

// 
void generalSetup(){
   // Set Additional Parameters
   
   // Set Camera Frames per second
   SetCameraFPSMode();

   // Set Camera Special Effects
   specialEffects();
    
   // Set Camera Automatic Exposure Control
   //SetCameraAEC();
   setupAEC();
   
   // Set Camera Automatic White Balance
   SetupCameraAWB();
   
   // Setup Undocumented Registers - Needed Minimum
   SetupCameraUndocumentedRegisters();
   
   // Set Camera Saturation
   SetCameraSaturationControl();
   
    // Denoise and Edge Enhancement     fix checkout denoistedgeenhancement and setupcameraedgenhancement(edge_value)
    // also check the flag for edge_on
   SetupCameraDenoiseEdgeEnhancement();
   SetupCameraDenoise();
   
   
   // Set up Camera Array Control
   SetupCameraArrayControl();
   
   
   // Set ADC Control
   SetupCameraADCControl();
   
   
   // Set Automatic Black Level Calibration
   SetupCameraABLC();

   // Set Color Bar test display
   SetupCameraColorBar();

   // Set Image mirror and flip
   setupMVFP();

   // set the UV average
   setupUV_Average();

   // set the image brightness
   setupBrightness();

   // set the output format type
   setupOutputType();
   // set the banding parameters
     setupBanding();
   // set the AGC
     setupAGC();
   // set contrast
   setupContrast();
   // light mode sunny/cloudy/office/home etc
   setupLightMode();
   // setup saturation
   setupSaturation();
   // load gamma curve
   load_gamma_curve();
} // end general_setup()


// ----------------------------------------------------------------------------------------------------------
void ResetCameraRegisters()
{
  // Reset Camera Registers
  // Reading needed to prevent error
  byte data = ReadRegisterValue(COM7);
  int result = OV7670WriteReg(COM7, COM7_VALUE_RESET );
  Serial.println(F("Camera Reset!: "));

  // Delay at least 500ms 
  delay(1000);
  OV7670WriteReg(COM10, 0x02);  // this sets register COM10 with a single bit 2^1 == 1 - "VSYNC Negative" ???
  // Delay for registers to settle
  delay(100);
  // setup the PLL and divider (CLKRC) to make a 24Mhz clock from the 12MHZ xtal on the camera board
  OV7670WriteReg(DBLV,0x40);       // PLL to * 4
  OV7670WriteReg(CLKRC,0x81);         // clock divider divide by 2
  Serial.println(F("PLL set for 24Mhz"));
  OV7670WriteReg(GFIX,0x52);       // set the BLUE gain to 1.5 and the Gr & Gb to 1.5 - better picture for this camera
  Serial.println(F("GFIX gain set"));
}


// %% called only once
void SetupCameraAdvancedAutoWhiteBalanceConfig()
{
  
   Serial.println(F("........... Setting Camera Advanced Auto White Balance Configs ........"));
   OV7670WriteReg(AWBC1, AWBC1_VALUE);
   OV7670WriteReg(AWBC2, AWBC2_VALUE);
   OV7670WriteReg(AWBC3, AWBC3_VALUE);
   OV7670WriteReg(AWBC4, AWBC4_VALUE);
   OV7670WriteReg(AWBC5, AWBC5_VALUE);
   OV7670WriteReg(AWBC6, AWBC6_VALUE);
   OV7670WriteReg(AWBC7, AWBC7_VALUE);
   OV7670WriteReg(AWBC8, AWBC8_VALUE);
   OV7670WriteReg(AWBC9, AWBC9_VALUE);
   OV7670WriteReg(AWBC10, AWBC10_VALUE);
   OV7670WriteReg(AWBC11, AWBC11_VALUE);
   OV7670WriteReg(AWBC12, AWBC12_VALUE);
   OV7670WriteReg(AWBCTR3, AWBCTR3_VALUE);
   OV7670WriteReg(AWBCTR2, AWBCTR2_VALUE);
   OV7670WriteReg(AWBCTR1, AWBCTR1_VALUE);
}

// %% called once
// mods 4/24/16 --- more work later
void SetupCameraFor30FPS()
{
   int result = 0;
   String sresult = "";
   
   if(detail)Serial.println(F("........... Setting Camera to 30 FPS ........"));
   result = OV7670WriteReg(COM11, 0x12);   // should be 0x12 for less exposure time in bright light & enable 50/60 hz detector
}


// 
void SetupCameraABLC()
{
   int result = 0;
   String sresult = "";
   if(detail == true)Serial.println(F("........ Setting Camera ABLC ......."));   
   // If ABLC is off
   if(!(testflag(ablcon_on)))
   {
     clearReg(ABLC1,ABLC1_VALUE_ON);
     return;
   }
   result = setReg(ABLC1, ABLC1_VALUE_ON);
   result = OV7670WriteReg(THL_ST, THL_ST_VALUE); // target value is 0x82 - default is 80
}


// --------------------------------------
void SetupVGA()
{

   Serial.println(F("--------------------------- Setting Camera for VGA ---------------------------"));
  
//   PHOTO_WIDTH  = 640;
//    PHOTO_HEIGHT = 480; 
//   PHOTO_BYTES_PER_PIXEL = 1;      // should be one for raw Bayer output set in output type

   // Basic Registers
   clearReg(COM7,CLEAR_RESOLUTION_BITS);     // set for VGA resolution
//   output_format = BAYERRAW;
   generalSetup();       // all control registers set here
}    // end of SetupVGA


// all the registers stand alone - ie no resolution etc.
// this routine is fixed
void SetupCameraAverageBasedAECAGC()
{
   int result = 0;
   String sresult = "";
   
   Serial.println(F("-------------- Setting Camera Average Based AEC/AGC Registers ---------------"));

   // add code to set registers COM4 and COM 17 bits to enable? the average options+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/*   
   result = setReg(COM4,0x20); // bit 5 set 1/4 window

   result = setReg(COM17,0x80); // bit 7 set 1/4 window
*/
   
   result = OV7670WriteReg(AEW, AEW_VALUE);  // AGC stable reagion upper - value 95, default = 75

   result = OV7670WriteReg(AEB, AEB_VALUE); // AGC stable reagion lower - value 33, default = 63

   result = OV7670WriteReg(VPT, VPT_VALUE);  // AGC/AEC Fast mode operating region

/*   
 *    bit 7 is the setting - one == histogram based AEC, 0 == average based AEC, rest of register is reserved
*/
// set bit correctly for the average based AEC
   result = clearReg(HAECC7,0x80);
}  // end of SetupCameraAverageBasedAECAGC()

// ---------------------------------------------------------------------------------
void SetCameraHistogramBasedAECAGC()
{

   // HAECC7 has one bit that is used the rest of the register is "reserved"
   setReg(HAECC7,HISTOGRAM_BASED_AECAGC);        // There is a companion routine for averaged based AECAGC                                                                 
}

// ----------------------------------------------------------------------------------
void SetupOV7670ForQVGAYUV()
{
   int result = 0;
   String sresult = "";
   Serial.println(F("--------------------------- Setting Camera for QVGA (YUV) ---------------------------"));
   PHOTO_WIDTH  = 320;
   PHOTO_HEIGHT = 240; 
   PHOTO_BYTES_PER_PIXEL = 2;
   
   
   // Basic Registers
   setReg(CLKRC, CLKRC_VALUE_QQVGA & 0X7F);  // default 0x80 this sets 0x81

   clearReg(COM7,0x3f);   // clear output format selection and RGB bit
   setReg(COM7,0x10);   // set bit QVGA in COM7  to select QVGA
// problems with the switch from QQVGA to QVGA
// DCW ??? enabled maybe - so clear the three bits that control this
   clearReg(COM3,0x04 );   // [2] = 1 "DCW enable for prefdefined formats 
   clearReg(COM14,0x18);  // [4]= 1 "DCW & PCLK manual control", [3] = 1 "Adjust per defined scaling parameters"

   // Set Additional Parameters
   setupQVGAScaling();
   generalSetup();
   // setup the strange windows registers
   setupQVGAWindow();
}    //   end of SetupOV7670ForQVGAYUV()


// ----------- this is required for a QVGA mode to work ------------------------------
void setupQVGAWindow(){
int result;
String sresult;
byte reg;     
       
   // Serial.println(F("........... Setting Camera Window Output Parameters  ........"));
 
   // Change Window Output parameters after custom scaling
   // HSTART,HSTOP & VSTRT,VSTOP are 8 bit registers holding the MS part of 11 bit and 10 bit numbers respectively
   // HREF and VREF hold the LS bits packed into two three bits in HFEF and into two two bits in VREF
    
   result = OV7670WriteReg(HSTART, HSTART_VALUE_QVGA );     // default = 0x11 , sets 0x13

   result = OV7670WriteReg(HSTOP, HSTOP_VALUE_QVGA );  // default = 0x61, sets 0x01

   reg = OV7670ReadReg(HREF);
   reg &= 0xC0;     // mask off the low order six bits - that leaves the default HREF edge offset to data set properly
   reg |= HREF_VALUE_QVGA & 0x3F;    // default = 0x80, sets 0x24 ( start 0x04, stop 0x04 ) [7:6] HREF edge offset to data zero = 0x02
   result = setReg(HREF,reg);
  
   result = OV7670WriteReg(VSTRT, VSTRT_VALUE_QVGA );  // default =0x03, sets 0x02 
  
   result = OV7670WriteReg(VSTOP, VSTOP_VALUE_QVGA );  // default 0x7b, sets 0x7a
  
   result =  setReg(VREF,VREF_VALUE_QVGA & 0x0F);    // default = 0, sets 0x0A ( start 0x02, stop 0x02) [7:6] = bits [9:8] of AGC

}
// ------------------- this is also required for QVGA to work ------------------------------------
void setupQVGAScaling(){
int result;
String sresult;     
     // problems with the switch from QQVGA to QVGA
// DCW ??? enabled maybe - so clear the three bits that control this
   result = clearReg(COM3,0x04 );   // [2] = 1 "DCW enable for prefdefined formats 
  
   result = clearReg(COM14,BIT4 | BIT3);  // [4]= 1 "DCW & PCLK manual control", [3] = 1 "Adjust per defined scaling parameters"    

   wait_for_sync(); // wait for the next VSYNC
   
   result = setReg(SCALING_XSC,SCALING_XSC_VALUE_QVGA & 0x7F ); // sets 0x3a - partial register [6:0]
  
   result = setReg(SCALING_YSC,SCALING_YSC_VALUE_QVGA & 0x7F ); // sets 0x35 - partial register [6:0]

     // SCALING_DCWCTR has six variables some interrelated  
   result = setReg(SCALING_DCWCTR, SCALING_DCWCTR_VALUE_QVGA & 0x3f );    // sets 0x11 - down sample vert & horiz by two

   // bits [7:4] are reserved and default to zeros, why 0xF, bit3 = 0 enables divider, bits [2:0] sets divider ratio 1 = divide by two  
   result = clearReg(SCALING_PCLK_DIV,BIT3);
   result = setReg(SCALING_PCLK_DIV,BIT1);
  
   result = OV7670WriteReg(SCALING_PCLK_DELAY,SCALING_PCLK_DELAY_VALUE_QVGA & 0x7F ); // sets 2  Default is 2, according to data sheet.

}
// debug - 8/7/16 --------- !!!!!!!!!!!!!!!!!!! This needs to be checked out per implementation guide could be a total screwup
void SetupCameraSimpleAutomaticWhiteBalance()
{
 // worked on this 7/4/16 - no change
   if(detail == true)Serial.println(F("........... Setting Camera to Simple AWB ........"));
  
   // COM8
   // this register has many control bits
   setReg(COM8,BIT1);  // AWB enable bit on

   // this register
   setReg(COM16,BIT3);  //     Automatic White Balance Gain enable

 
   // AWBCTR0  - need to find out about these
//   OV7670WriteReg(AWBCTR0, AWBCTR0_VALUE_NORMAL);  // value is 0x9f default is 0x9A
     clearReg(AWBCTR0,0x07);
     setReg(AWBCTR0,BIT3 | BIT0);  // AWB adjusts R,G & B gain, Normal AWB mode 
}
// 8/7/16 - need to work on this check the implementation guide
void SetupCameraAdvancedAutomaticWhiteBalance()
{
   
   int result = 0;
   String sresult = "";
   
   if(detail == true)Serial.println(F("........... Setting Camera to Advanced AWB ........"));
  
   // AGC, AWB, and AEC Enable
   OV7670WriteReg(COM8, 0xA7); // bits set: Enable fast AGC/AEC, Banding filter ON,AGC/AWB/AEC all enabled
    // this register
   setReg(COM16,BIT3);  //     Automatic White Balance Gain enable 
   // AWBCTR0 
   OV7670WriteReg(AWBCTR0, 0x9E); // default 0x9A - this set 0x9E why? 
}    // end of SetupCameraAdvancedAutomaticWhiteBalance() 

// working on this 4/25/16 - needs more color gain options
void SetupCameraGain()
{

   if(detail == true)Serial.println(F("........... Setting Camera Gain ........"));
// allow default for COM9 == X32

   // Set Blue Gain
   //{ REG_BLUE, 0x40 },
   OV7670WriteReg(BLUE, BLUE_VALUE);
  
   // Set Red Gain
   //{ REG_RED, 0x60 },
   OV7670WriteReg(RED, RED_VALUE);
   
   // Set Green Gain
   //{ 0x6a, 0x40 }, 
   OV7670WriteReg(GGAIN, GGAIN_VALUE);
   
   // Enable AWB Gain
   setReg(COM16,COM16_VALUE_AWB_GAIN_BIT);    // this is bit3

}

// called by general setup
void SetCameraSaturationControl()
{
  if(detail == true)Serial.println(F("........... Setting Camera Saturation Level ........"));
  OV7670WriteReg(SATCTR, SATCTR_VALUE & 0xF0);
}

void SetCameraFPSMode()
{
   // Set FPS for Camera
   if (testflag(FPS30))
   {
     SetupCameraFor30FPS();
   }    
   else
   {
          setReg(COM11,BIT7 | BIT6 | BIT5);  // night mode and frame rate 1/8 of normal as necessary   
   }
}

// the two routines called by this have been fixed
void SetCameraAEC()
{
    // Process AEC
    Serial.println(F("Set AEC called --------------------------------------"));
   if (!(testflag(aec_histogram)))
   {
     // Set Camera's Average AEC/AGC Parameters
     // have done this (I think)
     Serial.println(F("Setting up average basec AEC ----------------------------------------------"));  
     SetupCameraAverageBasedAECAGC();  
   }
   else
   if (testflag(aec_histogram))
   { 
     // Set Camera AEC algorithim to Histogram
     SetCameraHistogramBasedAECAGC();
   }
}

void SetupCameraAWB()
{
   // Set AWB Mode
   if (!(testflag(aawb_on)))
   {
     // Set Simple Automatic White Balance
     SetupCameraSimpleAutomaticWhiteBalance(); // OK
      
     // Set Gain Config
     SetupCameraGain();
   }
   else
   if (testflag(aawb_on))
   {
     // Set Advanced Automatic White Balance
     SetupCameraAdvancedAutomaticWhiteBalance(); // ok
   
     // Set Camera Automatic White Balance Configuration
     SetupCameraAdvancedAutoWhiteBalanceConfig(); // ok
     
     // Set Gain Config
     SetupCameraGain();
   }
}


void SetupCameraDenoise()
{  
   if(detail == true)Serial.println(F("........... Setting Camera Denoise  ........"));
  
   OV7670WriteReg(DNSTH, de_noise_threshold);
   OV7670WriteReg(REG77, de_noise_reg77);
}


void SetupCameraEdgeEnhancement(byte e_in)
{
   int result = 0;
   byte temp = 0;
   byte mask = 0x01f;
      
   if(detail == true)Serial.println(F("........... Setting Camera Edge Enhancement  ........"));
   temp = mask & e_in;
   if(testflag(edge_on))setReg(COM16,BIT5);             // set Enhancement ON
   else
   {
   clearReg(COM16,BIT5);      // if edge bit is on then EDGE is filled by hardware
   clearReg(EDGE,mask);       // else this value will control enhancement
   setReg(EDGE,temp);
   }
}



void SetupCameraDenoiseEdgeEnhancement()
{
   if (testflag(denoise_on)&& 
       (testflag(edge_on)))
      {
        SetupCameraDenoise();
        SetupCameraEdgeEnhancement((byte)edge_value);
        OV7670WriteReg(COM16, COM16_VALUE_DENOISE_ON__EDGE_ENHANCEMENT_ON__AWBGAIN_ON);
      }
      else
      if ((testflag(denoise_on))&& 
          (!(testflag(edge_on))))
       {
         SetupCameraDenoise();
         OV7670WriteReg(COM16, COM16_VALUE_DENOISE_ON__EDGE_ENHANCEMENT_OFF__AWBGAIN_ON);
       }
       else
       if (!(testflag(denoise_on))&& 
          (testflag(edge_on)))
          {
            SetupCameraEdgeEnhancement((byte)edge_value);
            OV7670WriteReg(COM16, COM16_VALUE_DENOISE_OFF__EDGE_ENHANCEMENT_ON__AWBGAIN_ON);
          }
}

void SetupCameraArrayControl()     // sets default for ARBLM, sets 0xb for CHLF default is 8
{
   if(detail == true)Serial.println(F("........... Setting Camera Array Control  ........"));
  
   OV7670WriteReg(CHLF, CHLF_VALUE);
 
   OV7670WriteReg(ARBLM, ARBLM_VALUE);

}


// all the registers in this routine are reserved! They have defaults
void SetupCameraADCControl()  // This is 
{
   if(detail == true)Serial.println(F("........... Setting Camera ADC Control  ........"));
   OV7670WriteReg(ADCCTR1, ADCCTR1_VALUE);
   OV7670WriteReg(ADCCTR2, ADCCTR2_VALUE);
   OV7670WriteReg(ADC, ADC_VALUE);
   OV7670WriteReg(ACOM, ACOM_VALUE);
   OV7670WriteReg(OFON, OFON_VALUE);

}

// --------------- starting mods 7/3/16 ------------------------------- qqvgafix ------------------------------------------------

void SetupOV7670ForQQVGAYUV()
{

   if(detail == true)Serial.println(F("--------------------------- Setting Camera for QQVGA YUV ---------------------------"));
  
   PHOTO_WIDTH  = 160;
   PHOTO_HEIGHT = 120; 
   PHOTO_BYTES_PER_PIXEL = 2;
   setReg(CLKRC, CLKRC_VALUE_QQVGA & 0X7F);  // default 0x80 this sets 0x81

   setReg(COM3, COM3_VALUE_QQVGA);           // sets to 0x04 - "DCW enable" must set COM7 & COM14 also
   clearReg(COM7,BIT5 | BIT4 | BIT3);         // set the format bits to zero to invoke the VGA mode   
   setReg(COM14, COM14_VALUE_QQVGA & 0x1F ); // set to a 0x1A -  bits 4,3 and 1 set. Bit 4 is DCW and scaling PCLK.   
                                                      // [4]=1 -  scaling PCLK controlled by COM14[2:0]  
                                                      // and SCALING_PCLK_DIV[3:0](0x73)
                                                      // Bit 3 Manual scaling enabled for pre-defined resoulutions - CIF,QCIF and QVGA     
                                                      // Bits[2:0]= 010 PCLK divider divided by 4
  
// The scaling XSC & YSC registers are set to the defaults at this point - a reset is called before calling this routine
 
   clearReg(SCALING_DCWCTR,0X33);  // clear bits [5:4] and [1:0]
   setReg(SCALING_DCWCTR, SCALING_DCWCTR_VALUE_QQVGA & 0x33 ); // reg 0x72 SCALING_DCWCTR, default= 0x11, sets 0x22.  
   setReg(SCALING_PCLK_DIV, SCALING_PCLK_DIV_VALUE_QQVGA & 0x0F); //reg 0x73 SCALING_PCLK_DIV ,default = 0, sets 0x02.  
  // new -------------
  generalSetup();
  wait_for_sync(); // added just in case - these window setting make no sense, HSTOP less than HSTART
     
   // the H registers must be set for scan to be recognized 
   // Change Window Output parameters after custom scaling
   // HSTART,HSTOP,VSTRT and VSTOP are 8 bit dedicated registers and can be set by a full register write
   OV7670WriteReg(HSTART, HSTART_VALUE_QQVGA );    // 0x17 default = 11x   sets = 13x
  
   OV7670WriteReg(HSTOP, HSTOP_VALUE_QQVGA );    // 0x18 default = 61x   sets = 1  

   // HREF holds two three bit and one two bit multi purpose subregisters. Horizontial start/stop LS bits are stored in the two three bit
   // subregisters [2:0] holds the start ls bits, and [5:3] holds the stop bits
   // merging the two give a hex mask of 0x3F
   clearReg(HREF,0x3F);       // clear bits [5:0] here the default is 0x80 (in the one two bit register HREF edge offset to data output)
   setReg(HREF,HREF_VALUE_QQVGA & 0X3f);      // set the new data 0xA4
   // the vertical registers can be omitted - with no effect - WHY???
   OV7670WriteReg(VSTRT, VSTRT_VALUE_QQVGA );      // 0x19 default = 0x03, is set to 0x02
   OV7670WriteReg(VSTOP, VSTOP_VALUE_QQVGA );      // 0x1A default = 0x7B, is set to 0x7a

  // VREF has four sub registers of two bits each. [7:6] have AGC data, [5:4] is reserved, [2:3] is ls bits of VSTOP, [1:0] is ls bits of VSTRT
   clearReg(VREF, 0x0F);       // loose the old data
   setReg(VREF,VREF_VALUE_QQVGA & 0X0F); // default = 0, this sets a 0x0A
} // end of SetupOV7670ForQQVGAYUV()

void PulseLowEnabledPin(int PinNumber, int DurationMicroSecs)
{
  // For Low Enabled Pins , 0 = on and 1 = off
  digitalWrite(PinNumber, LOW);            // Sets the pin on
  delayMicroseconds(DurationMicroSecs);    // Pauses for DurationMicroSecs microseconds      
  
  digitalWrite(PinNumber, HIGH);            // Sets the pin off
  delayMicroseconds(DurationMicroSecs);     // Pauses for DurationMicroSecs microseconds  
}

void PulsePin(int PinNumber, int DurationMicroSecs)
{
  digitalWrite(PinNumber, HIGH);           // Sets the pin on
  delayMicroseconds(DurationMicroSecs);    // Pauses for DurationMicroSecs microseconds      
  
  digitalWrite(PinNumber, LOW);            // Sets the pin off
  delayMicroseconds(DurationMicroSecs);    // Pauses for DurationMicroSecs microseconds  
}

// undocumented registers are a mistrey to me ( along with spelling!)
void SetupCameraUndocumentedRegisters()
{ 
   // Write(0xb0,0x84); //adding this improve the color a little bit
   OV7670WriteReg(0xB0, 0x84);
}

void  SetupCameraColorBar()
{
    if(testflag(color_bar)){          
          // if COM7 not set color bar has two colors only ?
          setReg(COM7,0x02);  // set bit 1 == 1 to enable color bar
          // if COM17 not setup - picture is displayed
          setReg(COM17,0x08); // set bit 3 == 1 to enable color DSP bar display
          setReg(SCALING_XSC,(bar_type & 0x01)<<7);
          setReg(SCALING_YSC,(bar_type & 0x02)<<6);
     }
     else
     {
          clearReg(COM7,0x02);  // set bit 1 == 0 to disable color bar
          clearReg(COM17,0x08); // set bit 3 == 0 to disable DSP color bar display
          clearReg(SCALING_XSC,0x80);   // set color bar type to "no test output"
          clearReg(SCALING_YSC,0x80);
          
     }
}

void setupMVFP()
{
     // flip the camera format [5] = 1 mirror image, [4] = flip vertical
     if(image_mirror)
          setReg(MVFP,image_mirror);
          else
          clearReg(MVFP,0x20);
     if(image_flip)
          setReg(MVFP,image_flip);
          else
          clearReg(MVFP,0x10);
     if(detail){Serial.print("MVFP = ");Serial.println(ReadRegisterValue(MVFP),HEX);}
}

void setupUV_Average()
{
     if(uv_average)
          setReg(REG4B,uv_average);
          else
          clearReg(REG4B,1);
}

void setupBrightness()
{
     setReg(BRIGHT,brightness);    // this is a full 8 bit register set to 0,18,30,98 and B0 hex per Software Applications Note
}

void load_gamma_curve()
{
int reg_list[17];
int val_list[16];
int i = 0;
int j;
// get register list
     while(1){
       reg_list[i] = pgm_read_byte_far(gamma_register_list + i);
       if(reg_list[i] == 0xff)break;
       i++;    
     }
     switch(gamma_curve)
     {
          case 0:
          Serial.println(F("No gamma list set to load"));
          return;
          break;
          case 1:
            for(j=0; j<i;j++)val_list[j] = pgm_read_byte_far(gamma1 + j);
            break;
          case 2:
            for(j=0; j<i;j++)val_list[j] = pgm_read_byte_far(gamma2 + j);
            break;
          default:
            Serial.println(F("No valid gamma curve found"));
            return;
            break;                   
     }
     for(j=0;j<i;j++){
          if(reg_list[j] != 0xff)OV7670WriteReg(reg_list[j],val_list[j]);
     }
     
} // end of load_gamma_curve

