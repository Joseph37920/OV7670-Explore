// Mods: jsh 3/19/16

enum Output_Format_type{
     UYVY,
     VYUY,
     YVYU,
     YUYV,
     RGB565,
     RGB555,
     RGBx444,
     RGB444x,
     BAYERRAW,
     PROCESSEDBAYER
};

enum Band_Control_Type{
     BNULL,
     BOFF,
     B50,
     B60,
     BAUTO
};
// defines for routines in camera_functions.cpp

void ReadRegisters();
void ResetCameraRegisters();
void SetupCameraAdvancedAutoWhiteBalanceConfig();
void SetupCameraFor30FPS();
void SetupCameraABLC();
void SetupVGA();
void SetupOV7670ForVGAProcessedBayerRGB();
void SetupCameraAverageBasedAECAGC();
void SetCameraHistogramBasedAECAGC();
void SetupOV7670ForQVGAYUV();
void SetupCameraNightMode();
void SetupCameraSimpleAutomaticWhiteBalance();
void SetupCameraGain();
void SetCameraSaturationControl();
void SetCameraColorMatrixYUV();
void SetCameraFPSMode();
void SetCameraAEC();
void SetupCameraAWB();
void SetupCameraDenoise();
void SetupCameraEdgeEnhancement(byte e_in);
void SetupCameraDenoiseEdgeEnhancement();
void SetupCameraArrayControl();
void SetupCameraADCControl();
void SetupOV7670ForQQVGAYUV();
void PulseLowEnabledPin(int PinNumber, int DurationMicroSecs);
void PulsePin(int PinNumber, int DurationMicroSecs);
void SetupCameraUndocumentedRegisters();
int readExposure();
void printYUV();
void printDeNoise();
void printFixedGain();
void SetupCameraColorBar();
void setupMVFP();
void setupUV_Average();
void setupBrightness();
int setReg(int reg,byte val);
int clearReg(int reg,byte val);
void printWindowParameters();
void printScalingFactors();
void generalSetup();
void startWire();
byte ReadRegisterValue(int RegisterAddress);
int OV7670Write(int start, const byte *pData, int size);
int OV7670Read(int start, byte *buffer, int size);
//int OV7670ReadReg(int reg, byte *data);
int OV7670ReadReg(int reg);
int OV7670WriteReg(int reg, byte data);
int setReg(int reg,byte val);
int clearReg(int reg,byte val);
String ParseI2CResult(int result);
void showEdge();
void showDeNoise();
void showOutputType();
void setupOutputType();
void showBanding();
void setupBanding();
void showAGC();
void setupAGC();
void showAEC();
void setupAEC();
void showAWB();
void setupSaturation();
void showLightMode();
void setupLightMode();
void setupContrast();
void specialEffects();
void showflags();
void SetupCameraABLC();
String getRegName(int name_index);
void show_YUV_matrix();
void load_gamma_curve();
