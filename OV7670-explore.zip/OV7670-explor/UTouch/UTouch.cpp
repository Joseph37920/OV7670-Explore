/*
  UTouch.cpp - Arduino/chipKit library support for Color TFT LCD Touch screens 
  Copyright (C)2015 Rinky-Dink Electronics, Henning Karlsen. All right reserved
  
  Basic functionality of this library are based on the demo-code provided by
  ITead studio.

  You can find the latest version of the library at 
  http://www.RinkyDinkElectronics.com/

  This library is free software; you can redistribute it and/or
  modify it under the terms of the CC BY-NC-SA 3.0 license.
  Please see the included documents for further information.

  Commercial use of this library requires you to buy a license that
  will allow commercial use. This includes using the library,
  modified or not, as a tool to sell products.

  The license applies to all part of the library including the 
  examples and tools supplied with the library.
*/

//#define debug_printout 1

#include "UTouch.h"
#include "UTouchCD.h"

#if defined(__AVR__)
	#include "hardware/avr/HW_AVR.inc"
#elif defined(__PIC32MX__)
	#include "hardware/pic32/HW_PIC32.inc"
#elif defined(__arm__)
	#include "hardware/arm/HW_ARM.inc"
#endif

// --------------- kludge for touch position -----------------
#define x_offset 10
#define y_offset 5

UTouch::UTouch(byte tclk, byte tcs, byte din, byte dout, byte irq)
{
	T_CLK	= tclk;
	T_CS	= tcs;
	T_DIN	= din;
	T_DOUT	= dout;
	T_IRQ	= irq;
	Serial.println("Pin constructor called");
}

void UTouch::InitTouch(byte orientation)
{
	orient					= orientation;
	_default_orientation	= CAL_S>>31;
	touch_x_left			= (CAL_X>>14) & 0x3FFF;
	touch_x_right			= CAL_X & 0x3FFF;
	touch_y_top				= (CAL_Y>>14) & 0x3FFF;
	touch_y_bottom			= CAL_Y & 0x3FFF;
	disp_x_size				= (CAL_S>>12) & 0x0FFF;
	disp_y_size				= CAL_S & 0x0FFF;
	prec					= 10;
#if defined(debug_printout)
	Serial.print("touch_x_left ");Serial.println(touch_x_left);
	Serial.print("touch_x_right ");Serial.println(touch_x_right);
	Serial.print("touch_y_top ");Serial.println(touch_y_top);
	Serial.print("touch_y_botton ");Serial.println(touch_y_bottom);
	Serial.print("T_IRQ = ");Serial.println(T_IRQ);
#endif
	P_CLK	= portOutputRegister(digitalPinToPort(T_CLK));
	B_CLK	= digitalPinToBitMask(T_CLK);
	P_CS	= portOutputRegister(digitalPinToPort(T_CS));
	B_CS	= digitalPinToBitMask(T_CS);
	P_DIN	= portOutputRegister(digitalPinToPort(T_DIN));
	B_DIN	= digitalPinToBitMask(T_DIN);
	P_DOUT	= portInputRegister(digitalPinToPort(T_DOUT));
	B_DOUT	= digitalPinToBitMask(T_DOUT);
	P_IRQ	= portInputRegister(digitalPinToPort(T_IRQ));
	B_IRQ	= digitalPinToBitMask(T_IRQ);

	pinMode(T_CLK,  OUTPUT);
        pinMode(T_CS,   OUTPUT);
        pinMode(T_DIN,  OUTPUT);
        pinMode(T_DOUT, INPUT);
//        pinMode(T_IRQ,  OUTPUT);	// this should be an input!
	pinMode(T_IRQ, INPUT);
	sbi(P_CS, B_CS);
	sbi(P_CLK, B_CLK);
	sbi(P_DIN, B_DIN);	// from the view point of the driven chip
//	sbi(P_IRQ, B_IRQ);
//	Serial.println("Init Touch Called");
//	Serial.print("Clock line = ");Serial.println(T_CLK);
			cbi(P_CS, B_CS);	// select chip ( CS low)
			touch_WriteData(0x90);        
			pulse_high(P_CLK, B_CLK);
			touch_ReadData();	// read the x axis chip data
			touch_WriteData(0xD0);      
			pulse_high(P_CLK, B_CLK);
			touch_ReadData();	// read the y axis chip data
			sbi(P_CS, B_CS);	// deselect the chip (CS goes high)
}


// ----------- read X and Y from chip ----------------------
/* this routine has apparent serious bugs given the data in the Burr Brown 
	applications bulletin on the "pen interrupt" and the application note
	AB158 "Touch Screen Controller Tips"

	Also then placing the input readings the orientation appears to
	be checked and then not used in returning the data to the
	proper X and Y slots -- TP_X and TP_Y
*/ 
void UTouch::read()
{
	unsigned long tx=0, temp_x=0;
	unsigned long ty=0, temp_y=0;
	unsigned long minx=99999, maxx=0;
	unsigned long miny=99999, maxy=0;
	int datacount=0;

	cbi(P_CS, B_CS);	// select chip ( CS low)                    

//	pinMode(T_IRQ,  INPUT);		//redundant setup by init routine
//	Serial.print("Precision = ");Serial.println(prec);
	for (int i=0; i<prec; i++)
	{
		if (!rbi(P_IRQ, B_IRQ)) // is there a touch signal else return -1 for x & y
		{
			touch_WriteData(0x90);        
			pulse_high(P_CLK, B_CLK);
			temp_x=touch_ReadData();	// read the x axis chip data

			if (!rbi(P_IRQ, B_IRQ))	// still a touch signal
				{
				touch_WriteData(0xD0);      
				pulse_high(P_CLK, B_CLK);
				temp_y=touch_ReadData();	// read the y axis chip data

				if ((temp_x>0)			// range check on x & y
				 and (temp_x<4096) 
				 and (temp_y>0)
				 and (temp_y<4096))
				{
					tx+=temp_x;	// accumulate for average
					ty+=temp_y;
					if (prec>5)	// why is this hard coded?
					{
						if (temp_x<minx)	
							minx=temp_x;
						if (temp_x>maxx)
							maxx=temp_x;
						if (temp_y<miny)
							miny=temp_y;
						if (temp_y>maxy)
							maxy=temp_y;
					} // keep max and min of X & Y
					datacount++;
				}  // end of the range test on X & Y 
			} // end of test for touch still present to read Y
		} // end test for touch still present to read X
#ifdef debug_printout
	Serial.print(temp_x);Serial.print("  ");
	Serial.println(temp_y);
#endif
	}	// end of for prec loop

//	pinMode(T_IRQ,  OUTPUT);  // set IRQ to output (what is this?)
#ifdef debug_printout
	Serial.print("\n\n\n\n\n\n\n\n\nRead output calc\n\n");
	Serial.print("tx = ");Serial.println(tx/prec);
	Serial.print("ty = ");Serial.println(ty/prec);
	Serial.print("prec = ");Serial.println(prec);
	Serial.print("minx = ");Serial.print(minx);Serial.print(" maxx = ");Serial.println(maxx);
	Serial.print("miny = ");Serial.print(miny);Serial.print(" maxy = ");Serial.println(maxy);
#endif
	// what does this do for anything? Don't understand the math
	// is this an attempt to cleanup the data by throwing away
	// the high and low reading?
	if (prec>5)
	{
		tx = tx-(minx+maxx);
		ty = ty-(miny+maxy);
		datacount -= 2;		// reduction of data count just compensates for the subtraction
	}

	sbi(P_CS, B_CS);	// deselect the chip (CS goes high)

        // apparently somesort of test for full read of the touch count
	// if prec was > 5 on start - see setup - its set to 10 for some reason
	// ------- here is the problem: The TFT I have has the x,y contacts in a
	//	   mirror/inverted position, lower right is x,y == 0
	if ((datacount==(prec-2)) or (datacount==PREC_LOW))
	{
		// this checks if the calibration values CAL_S have the same orientation as the
		// value passed by the UTouch::InitTouch call
		// if they don't match X and Y values are exchanged 
		// this is to alter between PORTRAIT and LANDSCAPE
		if (orient == _default_orientation)
		{
			TP_X=ty/datacount;
			TP_Y=tx/datacount;
		}
		else
		{
			TP_X=tx/datacount;
			TP_Y=ty/datacount;
		}
	}
	else
	{
		TP_X=-1;
		TP_Y=-1;
//		Serial.println("Setting -1 to x & y");
	}
}

// ---------- poll the interrupt from the touch controller
bool UTouch::dataAvailable()
{
	bool avail;

//	pinMode(T_IRQ,  INPUT);		// make the pin an input
					// this should never be needed
					// who in going to change this pin's direction?

	avail = !(rbi(P_IRQ, B_IRQ));	// if its low its an interupt
//	Serial.print("Read IRQ = ");Serial.println(avail);
	return avail;
}


// ------------ return X as a pixel value ??
// no reference to hardware -- returns global
int16_t UTouch::getX()
{
	long c;

	if ((TP_X==-1) or (TP_Y==-1))
		return -1;
	if (orient == _default_orientation)
	{
		c = long(long(TP_X - touch_x_left) * (disp_x_size)) /
		 long(touch_x_right - touch_x_left);
		if (c<0)
			c = 0;
		if (c>disp_x_size)
			c = disp_x_size;
	}
	else
	{
		if (_default_orientation == PORTRAIT)
			c = long(long(TP_X - touch_y_top) * (-disp_y_size)) /
			 long(touch_y_bottom - touch_y_top) + long(disp_y_size);
		else
			c = long(long(TP_X - touch_y_top) * (disp_y_size)) /
			 long(touch_y_bottom - touch_y_top);
		if (c<0)
			c = 0;
		if (c>disp_y_size)
			c = disp_y_size;
	}
	// ------ have to flip x here depending on orientation
	if(_default_orientation == PORTRAIT) return (disp_y_size -c)-y_offset;
	if(_default_orientation == LANDSCAPE) return (disp_x_size -c)+x_offset;
	return c;
}

// ----------- return Y as a pixel value ?? ----------------------------
// no reference to hardware -- returns global
int16_t UTouch::getY()
{
	int c;

	if ((TP_X==-1) or (TP_Y==-1))
		return -1;
	if (orient == _default_orientation)
	{
		c = long(long(TP_Y - touch_y_top) * (disp_y_size)) /
		 long(touch_y_bottom - touch_y_top);
		if (c<0)
			c = 0;
		if (c>disp_y_size)
			c = disp_y_size;
	}
	else
	{
		if (_default_orientation == PORTRAIT)
			c = long(long(TP_Y - touch_x_left) * (disp_x_size)) /
			 long(touch_x_right - touch_x_left);
		else
			c = long(long(TP_Y - touch_x_left) * (-disp_x_size)) /
			 long(touch_x_right - touch_x_left) + long(disp_x_size);
		if (c<0)
			c = 0;
		if (c>disp_x_size)
			c = disp_x_size;
	}
	if(_default_orientation == PORTRAIT) return (disp_x_size -c)+x_offset;
	if(_default_orientation == LANDSCAPE) return (disp_y_size -c)-y_offset;
	return c;
}

// -----------  local control routine  --------------------

void UTouch::setPrecision(byte precision)
{
	switch (precision)
	{
		case PREC_LOW:
			prec=1;		// DO NOT CHANGE!
			break;
		case PREC_MEDIUM:
			prec=12;	// Iterations + 2
			break;
		case PREC_HI:
			prec=27;	// Iterations + 2
			break;
		case PREC_EXTREME:
			prec=102;	// Iterations + 2
			break;
		default:
			prec=12;	// Iterations + 2
			break;
	}
}
// ------- calibrateRead -------- 
// ------- code bracketed by the CS signal
// ------- this code reads only once
// ------ local vars tx & ty are long - read returns int16 - TP_X & TP_Y are also int 16
void UTouch::calibrateRead()
{
	unsigned long tx=0;
	unsigned long ty=0;

	cbi(P_CS, B_CS);                    

	touch_WriteData(0x90);        
	pulse_high(P_CLK, B_CLK);	// this is the 9th clock
	tx=touch_ReadData(); 		// this does 12 more clocks

	touch_WriteData(0xD0);      
	pulse_high(P_CLK, B_CLK);
	ty=touch_ReadData();

	sbi(P_CS, B_CS);                    

	TP_X=ty;
	TP_Y=tx;
}

