Place OV7670FIFO_Explore into your "Scketchbook" or other target for source.
Place UTFT-master into the library associated with the source code.
Place UTouch into the same library as above.

Read the hardware section of the Documentation for the Explore 
software, you may need to build or change your setup.

Note: There are mods to the UTFT-master the UTouch is not modified.
  The software uses it only in a test mode and it may be deleted
  without any problem.

Have fun. 
